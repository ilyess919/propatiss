# PROPATISS — thème « Maro » (bleu nuit + or)

- `css/maro-theme.css` : couleurs, polices (Cormorant Garamond + Montserrat), boutons contour doré, cartes carrées
- `css/rose-theme.css` : structure du menu (logo rond centré) et animations — conservées
- `js/rose-animations.js` : apparition au scroll, ondulation des boutons, flèche « haut de page »
- Couleur or : modifier `--gold` (#baa060) en haut de `maro-theme.css`
